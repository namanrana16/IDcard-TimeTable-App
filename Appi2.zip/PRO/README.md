# IDcard-TimeTable-App
An app to display your ID card and zoomable timetable
This App allows you to upload your ID and time table so that you won't have to search it anywhere else.
